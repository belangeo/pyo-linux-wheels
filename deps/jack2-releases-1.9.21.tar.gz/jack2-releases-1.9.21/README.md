# JACK2 binary releases

The git repository that provides the infrastructure for JACK2 binary releases.

These binary builds are completely automated, targetting Windows (32bit and 64bit mixed mode, cross-compiled using mingw) and macOS (native).

[Click here for the JACK2 binaries](https://github.com/jackaudio/jack2-releases/releases)
