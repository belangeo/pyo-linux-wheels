README-MINGW.txt -- note on MinGW and PortMidi

Roger Dannenberg
20 Sep 2010

Fabian Rutte writes that CMake can build files for Code::Blocks
under MinGW.

I would guess that a simple Unix Makefile output from CMake would
also work, but I haven't tested it.

